// Winner's Report Statistics Calculator
// Analyzes game data and generates comprehensive stats

export interface WinnerStats {
  // Game Overview
  totalTime: number; // milliseconds
  totalRounds: number;
  totalGuesses: number;
  
  // Highlight Moments
  lotteryWins: number;
  earlyWins: number;
  exactGuesses: number;
  bestRoundTime: number | null; // milliseconds
  
  // Deduction Breakdown
  deductionBreakdown: {
    zero: { count: number; percentage: number };
    one: { count: number; percentage: number };
    two: { count: number; percentage: number };
    three: { count: number; percentage: number };
  };
  
  // Skill Ratings
  deductionScore: number; // 0-10
  efficiencyRating: string; // S/A/B/C/D
  speedRank: string; // Lightning/Swift/Steady/Methodical
  
  // Achievements
  achievements: string[];
}

interface Guess {
  guess: number[];
  feedback: string;
  isLottery?: boolean;
  isWin?: boolean;
}

interface RoundData {
  player: string;
  secretNumber: number[];
  guesses: Guess[];
  pointsEarned: number;
  timeElapsed?: number | null;
}

export const calculateWinnerStats = (
  allRounds: RoundData[],
  totalGameTime: number
): WinnerStats => {
  
  // Initialize counters
  let totalGuesses = 0;
  let lotteryWins = 0;
  let earlyWins = 0;
  let exactGuesses = 0;
  let bestRoundTime: number | null = null;
  
  let zeroCorrect = 0;
  let oneCorrect = 0;
  let twoCorrect = 0;
  let threeCorrect = 0;
  
  let totalDigitsFound = 0;
  let totalPoints = 0;
  
  const achievements: string[] = [];
  let speedDemonRounds = 0;
  let clutchWins = 0;
  let perfectDeductionRounds = 0;
  
  // Analyze each round
  allRounds.forEach(round => {
    const roundGuesses = round.guesses.length;
    totalGuesses += roundGuesses;
    totalPoints += round.pointsEarned;
    
    // Check for highlight moments
    const firstGuess = round.guesses[0];
    if (firstGuess?.isLottery) {
      lotteryWins++;
    }
    
    // Early win = won on 2nd guess
    if (roundGuesses === 2 && round.guesses[1]?.isWin) {
      earlyWins++;
    }
    
    // Exact guess = won without arrangement phase (3+ correct on a playing guess)
    const wonBeforeArrangement = round.guesses.some((g, idx) => {
      // Check if this was a winning guess during "playing" phase
      // (not just finding all 3 digits, but getting exact match)
      return g.isWin && !g.isLottery && roundGuesses <= 6; // Assuming max 5 guesses + 1 exact = 6
    });
    
    if (wonBeforeArrangement && !firstGuess?.isLottery) {
      exactGuesses++;
    }
    
    // Track best round time
    if (round.timeElapsed != null) {
      if (bestRoundTime === null || round.timeElapsed < bestRoundTime) {
        bestRoundTime = round.timeElapsed;
      }
      
      // Speed demon: under 2 minutes (120000 ms)
      if (round.timeElapsed < 120000) {
        speedDemonRounds++;
      }
    }
    
    // Analyze deduction breakdown
    round.guesses.forEach(guess => {
      // Parse feedback to count correct digits
      const feedback = guess.feedback.toLowerCase();
      
      if (guess.isWin || guess.isLottery) {
        threeCorrect++; // Winning guess = all 3 correct
        totalDigitsFound += 3;
      } else if (feedback.includes('3 right')) {
        threeCorrect++;
        totalDigitsFound += 3;
      } else if (feedback.includes('2 right')) {
        twoCorrect++;
        totalDigitsFound += 2;
      } else if (feedback.includes('1 right')) {
        oneCorrect++;
        totalDigitsFound += 1;
      } else if (feedback.includes('0 right')) {
        zeroCorrect++;
      } else if (feedback === 'wrong order') {
        // This is an arrangement attempt - all 3 digits were correct
        threeCorrect++;
        totalDigitsFound += 3;
      }
    });
    
    // Check for clutch win (won on last guess or last arrangement)
    const lastGuess = round.guesses[round.guesses.length - 1];
    if (lastGuess?.isWin && roundGuesses >= 5) {
      clutchWins++;
    }
    
    // Check for perfect deduction (high % of 2-3 correct)
    const twoOrThreeCount = round.guesses.filter(g => {
      const fb = g.feedback.toLowerCase();
      return fb.includes('2 right') || fb.includes('3 right') || g.isWin;
    }).length;
    
    if (twoOrThreeCount / roundGuesses >= 0.6) {
      perfectDeductionRounds++;
    }
  });
  
  // Calculate percentages
  const totalDeductionGuesses = zeroCorrect + oneCorrect + twoCorrect + threeCorrect;
  
  const deductionBreakdown = {
    zero: {
      count: zeroCorrect,
      percentage: totalDeductionGuesses > 0 ? Math.round((zeroCorrect / totalDeductionGuesses) * 100) : 0
    },
    one: {
      count: oneCorrect,
      percentage: totalDeductionGuesses > 0 ? Math.round((oneCorrect / totalDeductionGuesses) * 100) : 0
    },
    two: {
      count: twoCorrect,
      percentage: totalDeductionGuesses > 0 ? Math.round((twoCorrect / totalDeductionGuesses) * 100) : 0
    },
    three: {
      count: threeCorrect,
      percentage: totalDeductionGuesses > 0 ? Math.round((threeCorrect / totalDeductionGuesses) * 100) : 0
    }
  };
  
  // Calculate Deduction Score (0-10)
  const avgDigitsPerGuess = totalDeductionGuesses > 0 ? totalDigitsFound / totalDeductionGuesses : 0;
  const deductionScore = Math.min(10, Math.round(avgDigitsPerGuess * 3.33)); // Scale 0-3 to 0-10
  
  // Calculate Efficiency Rating (S/A/B/C/D)
  const pointsPerGuess = totalGuesses > 0 ? totalPoints / totalGuesses : 0;
  let efficiencyRating = 'D';
  if (pointsPerGuess >= 20) efficiencyRating = 'S';
  else if (pointsPerGuess >= 15) efficiencyRating = 'A';
  else if (pointsPerGuess >= 10) efficiencyRating = 'B';
  else if (pointsPerGuess >= 5) efficiencyRating = 'C';
  
  // Calculate Speed Rank
  const avgRoundTime = bestRoundTime !== null && allRounds.length > 0
    ? allRounds.reduce((sum, r) => sum + (r.timeElapsed || 0), 0) / allRounds.length
    : 0;
  
  let speedRank = 'Methodical';
  if (avgRoundTime > 0) {
    if (avgRoundTime < 120000) speedRank = 'Lightning'; // < 2 min
    else if (avgRoundTime < 240000) speedRank = 'Swift'; // < 4 min
    else if (avgRoundTime < 360000) speedRank = 'Steady'; // < 6 min
  }
  
  // Determine Achievements
  if (lotteryWins > 0) {
    achievements.push('🎰 Perfect Game - Lottery Win!');
  }
  
  if (speedDemonRounds > 0) {
    achievements.push(`⚡ Speed Demon - ${speedDemonRounds} round${speedDemonRounds > 1 ? 's' : ''} under 2 min`);
  }
  
  if (deductionScore >= 7) {
    achievements.push('🧠 Deduction Master - High accuracy rate');
  }
  
  if (clutchWins > 0) {
    achievements.push('💪 Never Give Up - Won on final attempt');
  }
  
  if (perfectDeductionRounds >= Math.floor(allRounds.length / 2)) {
    achievements.push('🎯 Sharpshooter - Consistently strong guesses');
  }
  
  if (earlyWins >= 2) {
    achievements.push('🔥 Hot Streak - Multiple 2-guess wins');
  }
  
  return {
    totalTime: totalGameTime,
    totalRounds: allRounds.length,
    totalGuesses,
    lotteryWins,
    earlyWins,
    exactGuesses,
    bestRoundTime,
    deductionBreakdown,
    deductionScore,
    efficiencyRating,
    speedRank,
    achievements: achievements.slice(0, 4) // Max 4 achievements
  };
};

// Utility function to format time
export const formatTime = (milliseconds: number): string => {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  
  if (minutes >= 60) {
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `${hours}:${remainingMinutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  }
  
  return minutes > 0 
    ? `${minutes}:${seconds.toString().padStart(2, '0')}` 
    : `${seconds}s`;
};
