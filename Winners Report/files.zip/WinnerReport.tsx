import { useState } from 'react';
import { Trophy, Share2, X, Clock, Target, Zap, Brain } from 'lucide-react';
import { WinnerStats, formatTime } from './winnerStatsUtils';

interface WinnerReportProps {
  stats: WinnerStats;
  winnerName: string;
  onClose: () => void;
}

const WinnerReport = ({ stats, winnerName, onClose }: WinnerReportProps) => {
  const [copySuccess, setCopySuccess] = useState(false);
  
  const handleShare = async () => {
    const shareText = generateShareText();
    
    try {
      await navigator.clipboard.writeText(shareText);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    } catch (err) {
      // Fallback for older browsers
      const textArea = document.createElement('textarea');
      textArea.value = shareText;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    }
  };
  
  const generateShareText = (): string => {
    const { totalRounds, totalTime, deductionScore, efficiencyRating, lotteryWins } = stats;
    
    let text = `🎯 Secret Number - Winner's Report 🏆\n\n`;
    text += `${winnerName} won in ${totalRounds} rounds! ⚡\n`;
    text += `Time: ${formatTime(totalTime)}\n`;
    text += `Deduction: ${deductionScore}/10 🧠\n`;
    text += `Efficiency: ${efficiencyRating} 📊\n`;
    
    if (lotteryWins > 0) {
      text += `\n🎰 LOTTERY WIN! Perfect first guess!\n`;
    }
    
    text += `\nCan you beat this? 🎲`;
    
    return text;
  };
  
  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto">
      <div className="bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 rounded-2xl p-8 max-w-2xl w-full border-4 border-yellow-400 my-8 relative shadow-2xl">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-yellow-400 hover:text-yellow-300 transition-colors"
        >
          <X size={28} />
        </button>
        
        {/* Header */}
        <div className="text-center mb-8">
          <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-4 animate-bounce" />
          <h1 className="text-4xl font-bold text-white mb-2">Winner's Report</h1>
          <p className="text-2xl text-yellow-300 font-bold">{winnerName} Wins! 🎉</p>
        </div>
        
        {/* Game Overview */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 mb-6 border-2 border-white/20">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Clock className="text-blue-400" size={24} />
            Game Overview
          </h2>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-yellow-400">{formatTime(stats.totalTime)}</div>
              <div className="text-sm text-indigo-200">Total Time</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400">{stats.totalRounds}</div>
              <div className="text-sm text-indigo-200">Rounds</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pink-400">{stats.totalGuesses}</div>
              <div className="text-sm text-indigo-200">Total Guesses</div>
            </div>
          </div>
        </div>
        
        {/* Highlight Moments */}
        {(stats.lotteryWins > 0 || stats.earlyWins > 0 || stats.exactGuesses > 0 || stats.bestRoundTime) && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 mb-6 border-2 border-white/20">
            <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Zap className="text-yellow-400" size={24} />
              Highlight Moments
            </h2>
            <div className="space-y-3">
              {stats.lotteryWins > 0 && (
                <div className="flex items-center justify-between bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-lg p-3 border border-yellow-400/30">
                  <span className="text-white font-semibold">🎰 Lottery Wins</span>
                  <span className="text-yellow-400 font-bold text-xl">{stats.lotteryWins}</span>
                </div>
              )}
              
              {stats.earlyWins > 0 && (
                <div className="flex items-center justify-between bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg p-3 border border-green-400/30">
                  <span className="text-white font-semibold">⚡ Early Wins (2 guesses)</span>
                  <span className="text-green-400 font-bold text-xl">{stats.earlyWins}</span>
                </div>
              )}
              
              {stats.exactGuesses > 0 && (
                <div className="flex items-center justify-between bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg p-3 border border-purple-400/30">
                  <span className="text-white font-semibold">🎯 Exact Number Guesses</span>
                  <span className="text-purple-400 font-bold text-xl">{stats.exactGuesses}</span>
                </div>
              )}
              
              {stats.bestRoundTime && (
                <div className="flex items-center justify-between bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-lg p-3 border border-blue-400/30">
                  <span className="text-white font-semibold">⏱️ Best Round Time</span>
                  <span className="text-cyan-400 font-bold text-xl">{formatTime(stats.bestRoundTime)}</span>
                </div>
              )}
            </div>
          </div>
        )}
        
        {/* Deduction Breakdown */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 mb-6 border-2 border-white/20">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Brain className="text-purple-400" size={24} />
            Deduction Breakdown
          </h2>
          <div className="space-y-3">
            <DeductionBar
              label="0 digits correct"
              count={stats.deductionBreakdown.zero.count}
              percentage={stats.deductionBreakdown.zero.percentage}
              color="from-red-500 to-red-600"
            />
            <DeductionBar
              label="1 digit correct"
              count={stats.deductionBreakdown.one.count}
              percentage={stats.deductionBreakdown.one.percentage}
              color="from-yellow-500 to-yellow-600"
            />
            <DeductionBar
              label="2 digits correct"
              count={stats.deductionBreakdown.two.count}
              percentage={stats.deductionBreakdown.two.percentage}
              color="from-green-500 to-green-600"
            />
            <DeductionBar
              label="3 digits found"
              count={stats.deductionBreakdown.three.count}
              percentage={stats.deductionBreakdown.three.percentage}
              color="from-blue-500 to-purple-600"
            />
          </div>
        </div>
        
        {/* Skill Ratings */}
        <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 mb-6 border-2 border-white/20">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <Target className="text-green-400" size={24} />
            Skill Ratings
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-lg p-4 border border-purple-400/30 text-center">
              <div className="text-4xl font-bold text-purple-400 mb-1">{stats.deductionScore}<span className="text-2xl">/10</span></div>
              <div className="text-white font-semibold mb-1">🧠 Deduction Score</div>
              <div className="text-xs text-indigo-200">Avg digits found per guess</div>
            </div>
            
            <div className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 rounded-lg p-4 border border-yellow-400/30 text-center">
              <div className="text-4xl font-bold text-yellow-400 mb-1">{stats.efficiencyRating}</div>
              <div className="text-white font-semibold mb-1">📊 Efficiency Rating</div>
              <div className="text-xs text-indigo-200">Points earned per guess</div>
            </div>
            
            <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-lg p-4 border border-blue-400/30 text-center">
              <div className="text-lg font-bold text-cyan-400 mb-1">{stats.speedRank}</div>
              <div className="text-white font-semibold mb-1">⚡ Speed Rank</div>
              <div className="text-xs text-indigo-200">Based on solve time</div>
            </div>
          </div>
        </div>
        
        {/* Achievements */}
        {stats.achievements.length > 0 && (
          <div className="bg-white/10 backdrop-blur-lg rounded-xl p-6 mb-6 border-2 border-white/20">
            <h2 className="text-xl font-bold text-white mb-4">🏅 Special Achievements</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {stats.achievements.map((achievement, idx) => (
                <div
                  key={idx}
                  className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 rounded-lg p-3 border border-yellow-400/30"
                >
                  <span className="text-white font-semibold text-sm">{achievement}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {/* Share Button */}
        <button
          onClick={handleShare}
          className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white py-4 rounded-xl font-bold text-lg hover:from-green-600 hover:to-blue-600 transition-all transform hover:scale-105 flex items-center justify-center gap-2 border-2 border-white/20"
        >
          {copySuccess ? (
            <>
              ✓ Copied to Clipboard!
            </>
          ) : (
            <>
              <Share2 size={24} />
              Share My Stats
            </>
          )}
        </button>
      </div>
    </div>
  );
};

// Helper component for deduction bars
const DeductionBar = ({ 
  label, 
  count, 
  percentage, 
  color 
}: { 
  label: string; 
  count: number; 
  percentage: number; 
  color: string;
}) => {
  return (
    <div>
      <div className="flex justify-between text-sm text-white mb-1">
        <span>{label}</span>
        <span className="font-bold">{count} guesses ({percentage}%)</span>
      </div>
      <div className="w-full bg-white/10 rounded-full h-3 overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${color} transition-all duration-500 rounded-full`}
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};

export default WinnerReport;
